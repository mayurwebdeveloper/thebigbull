

## Install with data

```bash
php artisan migrate:fresh --seed 
```
