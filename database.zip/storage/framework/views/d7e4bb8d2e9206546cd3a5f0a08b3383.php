<?php $__env->startPush('title'); ?>
<title>Dashboard</title>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('main-section'); ?>

<div class="body flex-grow-1">
    <div class="container-lg px-4">
    <div class="row g-4 mb-4">
       
        <div class="col-sm-6 col-xl-3">
        <a href="<?php echo e(route('investment')); ?>" class="text-decoration-none">
          <div class="card text-white bg-primary">
            <div class="card-body pb-0 mb-3 d-flex justify-content-between align-items-start">
              <div>
                <div class="fs-4 fw-semibold"><?php echo e($totalInvestment); ?></div>
                <div>Total Investment</div>
              </div>
            </div>
          </div>
        </a>
        </div>

        <div class="col-sm-6 col-xl-3">
        <a href="<?php echo e(route('leader')); ?>" class="text-decoration-none">
          <div class="card text-white bg-info">
            <div class="card-body pb-0 mb-3 d-flex justify-content-between align-items-start">
              <div>
                <div class="fs-4 fw-semibold"><?php echo e($totalUsersWithRole); ?></div>
                <div>Total Leaders</div>
              </div>
            </div>
          </div>
        </a>
        </div>


        

    </div>


</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thebigbull\resources\views/dashboard.blade.php ENDPATH**/ ?>