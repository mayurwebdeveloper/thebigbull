


<?php $__env->startPush('title'); ?>
<title>Comission List</title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>
<!-- Custom styles for this page -->
<link href="<?php echo e(asset('vendors/datatables/dataTables.bootstrap5.css')); ?>" rel="stylesheet">


<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3" id="table-card-title">
        <h6 class="m-0 font-weight-bold text-primary">Comission</h6>
        <div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add investment')): ?>
            <button class="btn btn-primary" id="addUser" data-toggle="modal" data-target="#userModal"><i class="fas fa-plus"></i></button>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete investment')): ?>
            <button id="delete-selected" class="btn btn-danger"><i class="fas fa-trash"></i></button>
            <?php endif; ?>
        </div>
    </div>
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('userwisetotal')); ?>" class="mb-4">
            <div class="row">
                <div class="col-md-4">
                    <input type="text" name="username" class="form-control" placeholder="Username" value="<?php echo e(request('username')); ?>">
                </div>
               
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary">Filter</button>
                </div>
            </div>
        </form>
        <div class="table-responsive">
        <table class="table table-bordered" id="userTable" width="100%" cellspacing="0">
            <thead>
                <tr>
                  
                    <th>Leader Name</th>
                    <th>Comission Amount</th>
                    
                </tr>
              
                


            </thead>

            <tbody>
                <?php $__currentLoopData = $totalCommissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($comission->username); ?></td>
                    <td><?php echo e($comission->total_commission); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>  
        </div>
    </div>
</div>




<!-- Page level plugins -->
<script src="<?php echo e(asset('vendors/datatables/dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/datatables/dataTables.bootstrap5.js')); ?>"></script>

<script>
    $(document).ready(function () {
    
       
        var table = $('#userTable').DataTable();
    });
    </script>
    
    
    <?php if(Session::has('success')): ?>
    <script>
        Swal.fire(
        'Users!',
        '<?php echo e(Session::get("success")); ?>',
        'success'
        );
    </script>
    <?php
    Session::forget('success');
    ?>
    <?php endif; ?>
    
    <?php if(Session::has('error')): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: '<?php echo e(Session::get("error")); ?>',
        });
    </script>
    <?php
    Session::forget('error');
    ?>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thebigbull\resources\views/commissions/userwisetotal.blade.php ENDPATH**/ ?>