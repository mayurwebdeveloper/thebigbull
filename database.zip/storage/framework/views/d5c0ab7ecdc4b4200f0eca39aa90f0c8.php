</div>
</div>
</div>
<!-- CoreUI and necessary plugins-->
<script src="<?php echo e(asset('vendors/@coreui/coreui/js/coreui.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/simplebar/js/simplebar.min.js')); ?>"></script>
<script>
    const header = document.querySelector('header.header');

    document.addEventListener('scroll', () => {
        if (header) {
            header.classList.toggle('shadow-sm', document.documentElement.scrollTop > 0);
        }
    });
</script>
<script>
</script>

</body>

</html><?php /**PATH C:\xampp\htdocs\hospital-quiz\resources\views/layouts/footer.blade.php ENDPATH**/ ?>