<div class="sidebar sidebar-dark sidebar-fixed border-end" id="sidebar">
    <div class="sidebar-header border-bottom">
        <div class="sidebar-brand">
            <h5>Quiz App</h5>
        </div>
        <button class="btn-close d-lg-none" type="button" data-coreui-dismiss="offcanvas" data-coreui-theme="dark" aria-label="Close" onclick="coreui.Sidebar.getInstance(document.querySelector(&quot;#sidebar&quot;)).toggle()"></button>
    </div>
    <ul class="sidebar-nav" data-coreui="navigation" data-simplebar="">
        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                <svg class="nav-icon">
                    <use xlink:href="<?php echo e(asset('vendors/@coreui/icons/svg/free.svg#cil-speedometer')); ?>"></use>
                </svg> Dashboard</a>
        </li>

        
        <li class="nav-title">System:</li>
        <?php if(\App\Helpers\Helper::userAccessOr('view users', 'view roles')): ?>
        <li class="nav-group">
            <a class="nav-link nav-group-toggle" href="#">
                <svg class="nav-icon">
                    <use xlink:href="<?php echo e(asset('vendors/@coreui/icons/svg/free.svg#cil-user')); ?>"></use>
                </svg> Users
            </a>
            <ul class="nav-group-items compact">                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view users')): ?>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('users')); ?>"><span class="nav-icon"><span class="nav-icon-bullet"></span></span> Users</a></li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view roles')): ?>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('roles')); ?>"><span class="nav-icon"><span class="nav-icon-bullet"></span></span> roles</a></li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view permissions')): ?>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('permissions')); ?>"><span class="nav-icon"><span class="nav-icon-bullet"></span></span> Permission</a></li>
                <?php endif; ?>
            </ul>
        </li>
        <?php endif; ?>


        <li class="nav-title">Quiz:</li>
        <?php if(\App\Helpers\Helper::userAccessOr('view staff', 'view designations')): ?>
        <li class="nav-group">
            <a class="nav-link nav-group-toggle" href="#">
                <svg class="nav-icon">
                    <use xlink:href="<?php echo e(asset('vendors/@coreui/icons/svg/free.svg#cil-book')); ?>"></use>
                </svg> Staff
            </a>
            <ul class="nav-group-items compact">                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view designations')): ?>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('designation')); ?>"><span class="nav-icon"><span class="nav-icon-bullet"></span></span> Designations</a></li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view staff')): ?>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('staff')); ?>"><span class="nav-icon"><span class="nav-icon-bullet"></span></span> Staff</a></li>
                <?php endif; ?>
            </ul>
        </li>
        <?php endif; ?>

        <?php if(\App\Helpers\Helper::userAccessOr('view quizzes')): ?>
        <li class="nav-group">
            <a class="nav-link nav-group-toggle" href="#">
                <svg class="nav-icon">
                    <use xlink:href="<?php echo e(asset('vendors/@coreui/icons/svg/free.svg#cil-book')); ?>"></use>
                </svg> Quiz
            </a>
            <ul class="nav-group-items compact">                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view quizzes')): ?>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('quizzes')); ?>"><span class="nav-icon"><span class="nav-icon-bullet"></span></span> Quizzes</a></li>
                <?php endif; ?>
            </ul>
        </li>
        <?php endif; ?>



        <!-- <li class="nav-item">
            <a class="nav-link" href="colors.html">
                <svg class="nav-icon">
                    <use xlink:href="<?php echo e(asset('vendors/@coreui/icons/svg/free.svg#cil-drop')); ?>"></use>
                </svg> Colors
            </a>
        </li> -->

    </ul>
    <div class="sidebar-footer border-top d-none d-md-flex">
        <button class="sidebar-toggler" type="button" data-coreui-toggle="unfoldable"></button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\hospital-quiz\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>