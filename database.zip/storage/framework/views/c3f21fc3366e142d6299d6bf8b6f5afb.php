


<?php $__env->startPush('title'); ?>
<title>Investment List</title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>
<!-- Custom styles for this page -->
<link href="<?php echo e(asset('vendors/datatables/dataTables.bootstrap5.css')); ?>" rel="stylesheet">

<script>
    //open edit model with data
    function editUser(id) {
    $.ajax({
            url: "<?php echo e(route('edit-investment-form', ['id' => ''])); ?>/" + id, // Pass the id here
            type: "GET",
            success: function (data) {
                // Handle success
                $('#userModalLabel').text("edit Investment");
                $('#user_id').val(data.user_id);
                $('#investment_id').val(data.investment_id);
                $('#investment_amount').val(data.investment_amount);
                console.log(data); // Check the value

                $('#userModal').modal('show');
            },
            error: function () {
                // Handle error
                alert('An error occurred.');
            }
        });
    }

</script>
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3" id="table-card-title">
        <h6 class="m-0 font-weight-bold text-primary">Users</h6>
        <div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add investment')): ?>
            <button class="btn btn-primary" id="addUser" data-toggle="modal" data-target="#userModal"><i class="fas fa-plus"></i></button>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete investment')): ?>
            <button id="delete-selected" class="btn btn-danger"><i class="fas fa-trash"></i></button>
            <?php endif; ?>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
        <table class="table table-bordered" id="userTable" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th><input type="checkbox" id="check-all"></th>
                    <th>Leader Name</th>
                    <th>Investment Amount</th>
                    <th>Status</th>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit investment')): ?>
                    <th>Edit</th>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete investment')): ?>
                    <th>Delete</th>
                    <?php endif; ?>
                </tr>
            </thead>
        </table>  
        </div>
    </div>
</div>



<!--user-form-modal -->
<div class="modal fade" id="userModal" tabindex="-1" role="dialog" aria-labelledby="userModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="userModalLabel">Investment Form</h5>
        <button type="button" class="btn-close" data-coreui-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="<?php echo e(route('add-investment')); ?>" method="post">
        <div class="modal-body">
          <div class="form-group">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" id="investment_id" value="0">

            <div class="form-group">
                <label for="user_id" class="col-form-label">Leader:</label>
                <select class="form-control" name="user_id" id="user_id" >
                    <?php $__currentLoopData = $leaders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leader): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($leader->id); ?>"><?php echo e($leader->name); ?></option>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            <label for="name" class="col-form-label">Investment Amount:</label>
            <input type="text" class="form-control" name="investment_amount" id="investment_amount" oninvalid="this.setCustomValidity('Investment Amount field is required')" oninput="setCustomValidity('')" required>
          </div>
        
         

        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-coreui-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Save</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!--user-form-modal end-->

<!-- Page level plugins -->
<script src="<?php echo e(asset('vendors/datatables/dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/datatables/dataTables.bootstrap5.js')); ?>"></script>

<script>
    $(document).ready(function () {
    
        $('#addUser').click(function(){
            $('#userModalLabel').text("add new user");
            $('#investment_id').val(0);
            $('#userModal').modal('show');
        });
    
        var table = $('#userTable').DataTable({
            serverSide: true,
            ajax: "<?php echo e(route('investment')); ?>",
            columns: [
                { data: 'checkbox', name: 'checkbox', orderable: false, searchable: false },
                { data: 'user_name', name: 'name' },
                { data: 'investment_amount', name: 'investment_amount' },
                { data: 'created_at',name: 'created'},
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit investment')): ?>
                { data: 'edit', name: 'edit', orderable: false, searchable: false },
                <?php endif; ?>
    
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete investment')): ?>
                { data: 'delete', name: 'delete', orderable: false, searchable: false },
                <?php endif; ?>
            ],
            // "order": [[0, "desc"]]
        });
    
        // Handle the "Check All" checkbox
        $('#check-all').click(function () {
            $('input:checkbox').not(this).prop('checked', this.checked);
        });
    
    
        // Handle "Delete Selected" button click
        $('#delete-selected').click(function () {
            var selectedIds = [];
            $('input[name="user_id[]"]:checked').each(function () {
                selectedIds.push($(this).val());
            });
    
            if (selectedIds.length === 0) {
                // alert("Please select at least one record to delete.");
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Please select at least one record to delete.',
                });
            } else {
                
               Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: "<?php echo e(route('investment.deleteSelected')); ?>",
                            type: "POST",
                            data: {
                                selectedIds: selectedIds,
                                _token: "<?php echo e(csrf_token()); ?>"
                            },
                            success: function (data) {
                                // Handle success
                                table.ajax.reload();
                                if(data.status == 'success')
                                {
                                    Swal.fire(
                                    'Deleted!',
                                    'leader has been deleted.',
                                    'success'
                                    );
                                }else{
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Oops...',
                                        text: data.message,
                                    });
                                }
                            },
                            error: function (data) {
                                // Handle error
                                console.log(data);
                            }
                        });
                    }
                });
    
            }
        });  
        
    
    });
    </script>
    
    
    <?php if(Session::has('success')): ?>
    <script>
        Swal.fire(
        'Users!',
        '<?php echo e(Session::get("success")); ?>',
        'success'
        );
    </script>
    <?php
    Session::forget('success');
    ?>
    <?php endif; ?>
    
    <?php if(Session::has('error')): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: '<?php echo e(Session::get("error")); ?>',
        });
    </script>
    <?php
    Session::forget('error');
    ?>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thebigbull\resources\views/investment/list.blade.php ENDPATH**/ ?>